#!/bin/bash
/usr/bin/gtk-update-icon-cache .
/bin/bash ./icons.html.sh