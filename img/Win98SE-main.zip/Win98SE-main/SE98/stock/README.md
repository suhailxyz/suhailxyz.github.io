# Stock
Only the main icons are shown here (without symlinked duplicates, in sizes from 16x16 to 48x48).<br>The full icon list with sizes from 16x16 to 48x48 is there: [icons.md](icons.md)

| |**scalable**|**48x48**|**32x32**|**24x24**|**22x22**|**16x16**|
|-|-|-|-|-|-|-|
|**SC-categories-fonts**|![](scalable/SC-categories-fonts.svg)|![](48/SC-categories-fonts.png)|![](32/SC-categories-fonts.png)|![](24/SC-categories-fonts.png)|![](22/SC-categories-fonts.png)|![](16/SC-categories-fonts.png)|
|**stock_network-printer**|![](scalable/stock_network-printer.svg)|![](48/stock_network-printer.png)|![](32/stock_network-printer.png)|![](24/stock_network-printer.png)|![](22/stock_network-printer.png)|![](16/stock_network-printer.png)|
|**stock_new-meeting**|![](scalable/stock_new-meeting.svg)|![](48/stock_new-meeting.png)|![](32/stock_new-meeting.png)|![](24/stock_new-meeting.png)|![](22/stock_new-meeting.png)|![](16/stock_new-meeting.png)|
|**stock_people**|![](scalable/stock_people.svg)|![](48/stock_people.png)|![](32/stock_people.png)|![](24/stock_people.png)|![](22/stock_people.png)|![](16/stock_people.png)|
|**stock_person**|![](scalable/stock_person.svg)|![](48/stock_person.png)|![](32/stock_person.png)|![](24/stock_person.png)|![](22/stock_person.png)|![](16/stock_person.png)|
|**stock_person-panel**|![](scalable/stock_person-panel.svg)|![](48/stock_person-panel.png)|![](32/stock_person-panel.png)|![](24/stock_person-panel.png)|![](22/stock_person-panel.png)|![](16/stock_person-panel.png)|
